//
//  package com.lti.shopping.DAO;
//  
//  import java.util.List;
//
//import org.springframework.stereotype.Repository;
//
//import com.lti.shopping.model.Category;
//  
//  
//  @Repository
//  public interface CategoryDAO 
//  {
//	  	List<Category> listCategory();
//	  	Category get(int id);
//		Category getByName(String category_name); 
//  }
// 