//package com.lti.shopping.DAOImpl;
//
//import java.util.List;
//
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
//
//import com.lti.shopping.DAO.CategoryDAO;
//import com.lti.shopping.model.Category;
//@Repository("categoryDAO")
//public class CategoryDAOImpl implements CategoryDAO{
//
//	private static final Logger logger = 			
//			LoggerFactory.getLogger(UserDAOImpl.class);
//	
// 
//	Transaction tx;
//	@Autowired
//	private SessionFactory sessionFactory;
//	public void setSessionFactory(SessionFactory sf) {
//		this.sessionFactory = sf;
//	}
//	
//	@Override
//	public List<Category> listCategory() {
//		Session session = this.sessionFactory.getCurrentSession();
//		List<Category> categoryList = session.createQuery("from Category").list();
//		for (Category c :categoryList) 
//		{
//			logger.info("Person List::" + c);
//		}
//		return  categoryList;
//
//		 
//	}
//
//	@Override
//	public Category get(int id) {
//		Session session = this.sessionFactory.getCurrentSession();
//		Category c = (Category) session.load( Category.class, new Integer(id));
//		logger.info("category loaded successfully, category details=" + c);
//		return c;
// 
//		
//		 
//	}
//
//	@Override
//	public Category getByName(String category_name) {
//		Session session = this.sessionFactory.getCurrentSession();
//		Category c = (Category) session.load( Category.class, new String(category_name));
//
//
//		return c;
//	}
//
//}
