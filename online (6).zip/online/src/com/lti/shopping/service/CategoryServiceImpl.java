//package com.lti.shopping.service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.lti.shopping.DAO.CategoryDAO;
//import com.lti.shopping.model.Category;
//
//
//@Service
//@Transactional
//public class CategoryServiceImpl implements CategoryService {
//
//	@Autowired
//	private CategoryDAO categoryDAO;
//	
//	
//	public void setCategoryDAO(CategoryDAO categoryDAO) {
//		this.categoryDAO = categoryDAO;
//	}
//	
//	
//	@Override
//	@Transactional
//	public List<Category> listCategory(){
//		return this.categoryDAO.listCategory();
//	}
//	
//	
//	@Override
//	@Transactional
//	public Category get(int id) {
////		 
//		return this.categoryDAO.get(id);
//	}
//
//
//	@Override
//	public Category getByName(String category_name) {
//		return this.categoryDAO.getByName(category_name);
//	}
//
//}
